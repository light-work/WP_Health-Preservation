// pages/news/news.js
var WxParse = require('../wxParse/wxParse.js');
const { host, cloudHost, share, mealAppid, infoAppid} =require('../../utils/common.js')
Page({
    data: {
      cloudHost,
      foodInfo:'',
      property:'',
      showTip:true,
      articleArray:[],
      fitCount:0
    },
    onLoad: function(options) {
      const that = this;
      const id = options.id
      wx.showLoading({
        title: '加载中...',
      });
      wx.request({
        url: host + '/food/detail/' + id,
        success: function ({ data }) {
          if (data.errorCode === 0 && data.errorMsg === 'ok') {
            var content = data.data.content
            content = content.replace(new RegExp('/d/file', "gm"), cloudHost + '/d/file')
            that.setData({
              foodInfo:data.data.foodId,
              fitCount: data.data.fitCount,
              property: data.data.property
            })
            WxParse.wxParse('article', 'html', content, that, 5);
          }
          wx.hideLoading();
        },
        fail: function (error) {
          wx.hideLoading();
        }
      })
      wx.request({
        url: host + '/food/recommend/'+id,
        success: function ({ data }) {
          if (data.errorCode === 0 && data.errorMsg === 'ok') {
            that.setData({
              articleArray: data.articleArray
            })
          }
        }
      })
    },
  bindTapNewsView: (e) => {
    const item = e.detail
    if (item && item.articleType){
      wx.navigateToMiniProgram({
        appId: item.articleType==='meal'?mealAppid:infoAppid,
        path: `pages/choicest/main?id=${item.id}&category=${item.category}&type=${item.articleType}`,
        envVersion: 'develop'
      })
    }
  },
  foodConflictTap : function(e){
      wx.navigateTo({
        url: '../foodConflict/content?id=' + this.data.foodInfo.id,
      })
  },
  onShareAppMessage: function (ops) {
    const foodInfo = this.data.foodInfo
    return share(foodInfo.name + '的功效', '', '', foodInfo.picUrl)
  },
  onPageScroll: function (res) {
    const s = res.scrollTop
    const height = wx.getSystemInfoSync().windowHeight - 50
    if (height < s && this.data.showTip) {
      const that = this
      setTimeout(() => {
        that.setData({
          showTip: false
        })
      }, 1000)
    }
  }
})